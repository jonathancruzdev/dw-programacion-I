// Variables:
let html1 = '';
let html2 = '';
let colores = [
    'red',
    'green',
    'blue',
    'cyan',
    'magenta',
    'yellow',
    'black',
    'white',
    'orange',
    'pink',
    'tomato',
    'lime',
    'khaki',
    'orangered',
    'lightgreen',
    'lightblue',
    'aqua',
    'navy',
    'lemonchelo',
    'vermilion',
    'turquoise',
    'salmon',
    'chocolate',
    'goldenrod',
    'gamboge',
    'rebeccapurple',
    'lemonchiffon',
    'peru',
    '#FAFAFA',
];

// Recorrida del array:
